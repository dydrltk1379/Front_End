<template>
  <div>
      <Title/>
      <router-view>
      
      </router-view>
  </div>
</template>

<script setup>
import Title from './components/Title.vue';



</script>