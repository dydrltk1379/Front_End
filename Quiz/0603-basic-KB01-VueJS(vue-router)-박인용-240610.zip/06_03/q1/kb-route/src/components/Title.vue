<template lang="">
    <div>
        <div><router-link to="/">kb 길찾기</router-link></div>
        <button><router-link to="/BikeBox">자전거</router-link></button>
        <button><router-link to="/BusBox">버스</router-link></button>
        <button><router-link to="/WalkBox">뚜벅이</router-link></button>
    </div>
</template>

<script setup>

</script>