<template>
    <div>
        <div >
        <img src="https://img.freepik.com/free-vector/passengers-waiting-for-bus-in-city-queue-town-road-flat-vector-illustration-public-transport-and-urban-lifestyle_74855-8493.jpg?w=1800&t=st=1717485877~exp=1717486477~hmac=30d8f54f1c8c4c16731b04a1b9b7494313d7cb6dd43f04808d345841a8698dbf">
    </div>
    </div>
</template>

<script setup>

</script>