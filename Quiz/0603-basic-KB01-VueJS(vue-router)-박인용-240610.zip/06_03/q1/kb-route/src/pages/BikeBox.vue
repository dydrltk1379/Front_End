<template>
    <div>
        <img src="https://previews.123rf.com/images/supernick/supernick1602/supernick160200012/54671312-%EC%9E%90%EC%A0%84%EA%B1%B0-%EC%95%84%EC%9D%B4%EC%BD%98.jpg">
    </div>
</template>

<script setup>

</script>