<template>
    <div>
        <img src="https://media.istockphoto.com/id/814632144/ko/%EB%B2%A1%ED%84%B0/%EA%B1%B7%EB%8A%94-%EB%82%A8%EC%9E%90-%EB%B2%A1%ED%84%B0-%EC%95%84%EC%9D%B4%EC%BD%98-%EC%82%AC%EB%9E%8C%EB%93%A4-%EB%8F%84%EB%B3%B4-%EA%B8%B0%ED%98%B8-%EA%B7%B8%EB%A6%BC.jpg?s=1024x1024&w=is&k=20&c=of62fHg0C9T4lC5c4Npb0NPU7zjJ0-Lcfi3o7LBLbCo="/>
    </div>
</template>

<script setup>

</script>