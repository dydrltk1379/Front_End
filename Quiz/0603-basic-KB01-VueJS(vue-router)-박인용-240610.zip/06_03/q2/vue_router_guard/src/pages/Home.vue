<template>
    <div class="card card-body">
        <h2>Home</h2>
        <img src="https://i.namu.wiki/i/UHJqvB6CPT8IZFPIaj6ypU5siIJnixwhIdbepCeSbYw0S-dDvjBNA4pobS3Jvxi0_7O990-ItEg2eElaVhe2673iUui1TkfFtFERXkVCBSj3kl7rs-ONPEhp2q_popI-dHkWAujCxgVzUJWi4OrEuw.webp" alt="">
    </div>
</template>

<script setup>
</script>
