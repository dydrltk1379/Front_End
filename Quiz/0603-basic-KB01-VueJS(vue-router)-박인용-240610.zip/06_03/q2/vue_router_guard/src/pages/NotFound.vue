<template>
    <div class="card card-body">
        <h2 style="color:red;">Notfound!!</h2>
    </div>
</template>

<script setup>
</script>
