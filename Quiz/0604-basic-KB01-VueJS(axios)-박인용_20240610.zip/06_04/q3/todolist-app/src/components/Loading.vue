<template>
    <VueCsspin message="Loading" spin-style="cp-flip" />
</template>

<script setup>
import { VueCsspin } from 'vue-csspin'
import 'vue-csspin/dist/vue-csspin.css'
</script>
