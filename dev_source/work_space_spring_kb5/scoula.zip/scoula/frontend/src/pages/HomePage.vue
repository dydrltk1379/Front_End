<script setup></script>

<template>
  <h1>게시판 메인!!!</h1>
  <div>첫번째 페이지</div>
</template>
