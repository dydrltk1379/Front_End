<script setup></script>

<template>
  <main>추천 여행지</main>
</template>
