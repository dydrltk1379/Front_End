<script></script>
<template>
  <div class="my-5 p-3 text-center"><i class="fa-regular fa-copyright"></i> COPYRIGHTS KB FULLSTACK. ALL RIGHTS RESERVED.</div>
</template>
